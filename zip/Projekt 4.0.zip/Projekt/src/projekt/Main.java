package projekt;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    // dynamický seznam zaměstnanců
    static List<Zamestnanec> zamestnanci = new ArrayList<>();

    // automatické generování ID
    static int nextId = 1;

    // scanner pro vstup z klávesnice
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        boolean konec = false;

        // hlavní smyčka programu
        while (!konec) {

            vypisMenu();

            int volba = sc.nextInt();
            sc.nextLine(); // vyčištění bufferu

            switch (volba) {

                case 1:
                    pridejZamestnance();
                    break;

                case 2:
                    vypisZamestnance();
                    break;

                case 3:
                    pridejSpolupraci();
                    break;

                case 0:
                    konec = true;
                    break;

                default:
                    System.out.println("Neplatná volba");
            }
        }

        System.out.println("Program ukončen.");
    }

    // výpis menu
    static void vypisMenu() {
        System.out.println("\n--- MENU ---");
        System.out.println("1 - Přidat zaměstnance");
        System.out.println("2 - Vypsat zaměstnance");
        System.out.println("3 - Přidat spolupráci");
        System.out.println("0 - Konec");
        System.out.print("Volba: ");
    }

    // přidání zaměstnance
    static void pridejZamestnance() {

        System.out.println("Vyber skupinu:");
        System.out.println("1 - Datový analytik");
        System.out.println("2 - Bezpečnostní specialista");

        int typ = sc.nextInt();
        sc.nextLine();

        System.out.print("Zadej jméno: ");
        String jmeno = sc.nextLine();

        System.out.print("Zadej příjmení: ");
        String prijmeni = sc.nextLine();

        System.out.print("Zadej rok narození: ");
        int rok = sc.nextInt();
        sc.nextLine();

        Zamestnanec z;

        // vytvoření podle typu
        if (typ == 1) {
            z = new DatovyAnalytik(nextId++, jmeno, prijmeni, rok);
        } else {
            z = new BezpecnostniSpecialista(nextId++, jmeno, prijmeni, rok);
        }

        zamestnanci.add(z);

        System.out.println("Zaměstnanec přidán.");
    }

    // výpis zaměstnanců
    static void vypisZamestnance() {

        if (zamestnanci.isEmpty()) {
            System.out.println("Žádní zaměstnanci.");
            return;
        }

        for (Zamestnanec z : zamestnanci) {
            System.out.println(z);
        }
    }

    // přidání spolupráce
    static void pridejSpolupraci() {

        System.out.print("Zadej ID zaměstnance: ");
        int id1 = sc.nextInt();

        System.out.print("Zadej ID kolegy: ");
        int id2 = sc.nextInt();

        System.out.println("Úroveň spolupráce:");
        System.out.println("1 - Špatná");
        System.out.println("2 - Průměrná");
        System.out.println("3 - Dobrá");

        int volba = sc.nextInt();
        sc.nextLine();

        Zamestnanec z1 = najdiZamestnance(id1);
        Zamestnanec z2 = najdiZamestnance(id2);

        if (z1 == null || z2 == null) {
            System.out.println("Zaměstnanec nenalezen");
            return;
        }

        UrovenSpoluprace uroven;

        switch (volba) {
            case 1:
                uroven = UrovenSpoluprace.SPATNA;
                break;
            case 2:
                uroven = UrovenSpoluprace.PRUMERNA;
                break;
            default:
                uroven = UrovenSpoluprace.DOBRA;
        }

        // přidání spolupráce
        z1.pridejSpolupraci(z2, uroven);

        System.out.println("Spolupráce přidána");
    }

    // hledání zaměstnance podle ID
    static Zamestnanec najdiZamestnance(int id) {

        for (Zamestnanec z : zamestnanci) {
            if (z.getId() == id) {
                return z;
            }
        }

        return null;
    }
}